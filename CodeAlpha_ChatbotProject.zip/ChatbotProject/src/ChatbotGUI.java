import javax.swing.*;
import java.awt.*;

public class ChatbotGUI {

    private Chatbot bot;

    public ChatbotGUI() {
        bot = new Chatbot(); // Initialize the bot

        JFrame frame = new JFrame("AI Chatbot");
        frame.setSize(400, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextArea chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);

        JTextField inputField = new JTextField();
        JButton sendButton = new JButton("Send");

        frame.setLayout(new BorderLayout());
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(inputField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.setVisible(true);

        // Send message when button is clicked
        sendButton.addActionListener(e -> sendMessage(chatArea, inputField));

        // Send message when Enter key is pressed
        inputField.addActionListener(e -> sendMessage(chatArea, inputField));
    }

    private void sendMessage(JTextArea chatArea, JTextField inputField) {
        String userText = inputField.getText();
        if (!userText.isEmpty()) {
            chatArea.append("You: " + userText + "\n");
            String response = bot.getResponse(userText);
            chatArea.append("Bot: " + response + "\n");
            inputField.setText("");
        }
    }

    public static void main(String[] args) {
        new ChatbotGUI();
    }
}
