import java.util.HashMap;

public class Chatbot {

    private HashMap<String, String> knowledgeBase;

    public Chatbot() {
        knowledgeBase = new HashMap<>();
        initializeKnowledgeBase();
    }

    private void initializeKnowledgeBase() {
        knowledgeBase.put("hi", "Hello! How can I help you?");
        knowledgeBase.put("hello", "Hi there! How are you?");
        knowledgeBase.put("how are you", "I'm just a bot, but I'm fine. How about you?");
        knowledgeBase.put("what is your name", "I am ChatBot, your assistant.");
        knowledgeBase.put("bye", "Goodbye! Have a nice day!");
    }

    public String getResponse(String userInput) {
        userInput = userInput.toLowerCase();
        for (String key : knowledgeBase.keySet()) {
            if (userInput.contains(key)) {
                return knowledgeBase.get(key);
            }
        }
        return "Sorry, I don't understand that.";
    }

    public static void main(String[] args) {
        Chatbot bot = new Chatbot();
        System.out.println(bot.getResponse("hi"));
    }
}
