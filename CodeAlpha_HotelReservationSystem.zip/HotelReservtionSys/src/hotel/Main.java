package hotel;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		        Hotel hotel = new Hotel();
		        Scanner sc = new Scanner(System.in);

		        while (true) {
		            System.out.println("\n--- HOTEL RESERVATION SYSTEM ---");
		            System.out.println("1. View Available Rooms");
		            System.out.println("2. Book Room");
		            System.out.println("3. Cancel Booking");
		            System.out.println("4. View Bookings");
		            System.out.println("5. Exit");
		            System.out.print("Enter choice: ");

		            int choice = sc.nextInt();
		            sc.nextLine(); // clear buffer

		            switch (choice) {
		                case 1:
		                    hotel.showAvailableRooms();
		                    break;

		                case 2:
		                    hotel.showAvailableRooms();
		                    System.out.print("Enter Room ID: ");
		                    int roomId = sc.nextInt();
		                    sc.nextLine();
		                    System.out.print("Enter your name: ");
		                    String name = sc.nextLine();
		                    hotel.bookRoom(roomId, name);
		                    break;

		                case 3:
		                    System.out.print("Enter Booking ID: ");
		                    int bookingId = sc.nextInt();
		                    hotel.cancelBooking(bookingId);
		                    break;

		                case 4:
		                    hotel.viewBookings();
		                    break;

		                case 5:
		                    System.out.println("Thank you!");
		                    sc.close();
		                    return;

		                default:
		                    System.out.println("Invalid choice.");
		            }
		        }
		    }
		}


	


