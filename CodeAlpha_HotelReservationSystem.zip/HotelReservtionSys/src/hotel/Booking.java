package hotel;
import java.io.Serializable;

public class Booking implements Serializable {
	private static final long serialVersionUID = 1L;
		private int bookingId;
	    private String customerName;
	    private Room room;

	    // Constructor
	    public Booking(int bookingId, String customerName, Room room) {
	        this.bookingId = bookingId;
	        this.customerName = customerName;
	        this.room = room;
	    }

	    // Getters
	    public int getBookingId() {
	        return bookingId;
	    }

	    public String getCustomerName() {
	        return customerName;
	    }

	    public Room getRoom() {
	        return room;
	    }
	}


