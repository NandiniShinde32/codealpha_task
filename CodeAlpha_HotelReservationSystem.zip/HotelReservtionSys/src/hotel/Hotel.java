package hotel;
import java.io.*;
import java.util.*;
public class Hotel {
	    private List<Room> rooms;
	    private List<Booking> bookings;
	    private static final String FILE_NAME = "hotelData.dat";

	    // Constructor
	    public Hotel() {
	        loadData();
	    }

	    // Show available rooms
	    public void showAvailableRooms() {
	        System.out.println("\nAvailable Rooms:");
	        for (Room r : rooms) {
	            if (r.isAvailable()) {
	                System.out.println(
	                        "ID: " + r.getId() +
	                        " | Type: " + r.getType() +
	                        " | Price: ₹" + r.getPrice());
	            }
	        }
	    }

	    // Book a room
	    public void bookRoom(int roomId, String customerName) {
	        for (Room r : rooms) {
	            if (r.getId() == roomId && r.isAvailable()) {
	                r.setAvailable(false);

	                Booking booking = new Booking(
	                        bookings.size() + 1,
	                        customerName,
	                        r
	                );

	                bookings.add(booking);
	                saveData();

	                System.out.println("\nPayment Successful!");
	                System.out.println("Booking ID: " + booking.getBookingId());
	                return;
	            }
	        }
	        System.out.println("\nRoom not available.");
	    }

	    // Cancel booking
	    public void cancelBooking(int bookingId) {
	        Iterator<Booking> iterator = bookings.iterator();

	        while (iterator.hasNext()) {
	            Booking b = iterator.next();
	            if (b.getBookingId() == bookingId) {
	                b.getRoom().setAvailable(true);
	                iterator.remove();
	                saveData();
	                System.out.println("\nBooking cancelled successfully.");
	                return;
	            }
	        }
	        System.out.println("\nBooking not found.");
	    }

	    // View bookings
	    public void viewBookings() {
	        if (bookings.isEmpty()) {
	            System.out.println("\nNo bookings available.");
	            return;
	        }

	        System.out.println("\nBooking Details:");
	        for (Booking b : bookings) {
	            System.out.println(
	                    "Booking ID: " + b.getBookingId() +
	                    " | Name: " + b.getCustomerName() +
	                    " | Room: " + b.getRoom().getType() +
	                    " | Price: ₹" + b.getRoom().getPrice());
	        }
	    }

	    // Load data from file
	    @SuppressWarnings("unchecked")
	    private void loadData() {
	        try (ObjectInputStream ois =
	                     new ObjectInputStream(new FileInputStream(FILE_NAME))) {

	            rooms = (List<Room>) ois.readObject();
	            bookings = (List<Booking>) ois.readObject();

	        } catch (Exception e) {
	            rooms = new ArrayList<>();
	            bookings = new ArrayList<>();

	            rooms.add(new Room(1, "Standard", 1000));
	            rooms.add(new Room(2, "Deluxe", 2000));
	            rooms.add(new Room(3, "Suite", 3500));
	        }
	    }

	    // Save data to file
	    private void saveData() {
	        try (ObjectOutputStream oos =
	                     new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {

	            oos.writeObject(rooms);
	            oos.writeObject(bookings);

	        } catch (IOException e) {
	            System.out.println("Error saving data.");
	        }
	    }
	}


