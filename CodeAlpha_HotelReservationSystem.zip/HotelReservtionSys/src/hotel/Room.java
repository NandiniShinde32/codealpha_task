package hotel;

import java.io.Serializable;

public class Room implements Serializable {
	private static final long serialVersionUID = 1L;
		private int id;
	    private String type;
	    private double price;
	    private boolean available;

	    // Constructor
	    public Room(int id, String type, double price) {
	        this.id = id;
	        this.type = type;
	        this.price = price;
	        this.available = true;
	    }

	    // Getters
	    public int getId() {
	        return id;
	    }

	    public String getType() {
	        return type;
	    }

	    public double getPrice() {
	        return price;
	    }

	    public boolean isAvailable() {
	        return available;
	    }

	    // Setter
	    public void setAvailable(boolean available) {
	        this.available = available;
	    }
	}


