package stocktrading;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Portfolio {
	    private Map<String, Integer> holdings = new HashMap<>();
	    private List<Transaction> transactions = new ArrayList<>();
	    private double cashBalance = 10000.0; // starting balance

	    public void buyStock(Stock stock, int quantity) {
	        double cost = stock.getPrice() * quantity;

	        if (cost > cashBalance) {
	            System.out.println("❌ Not enough balance.");
	            return;
	        }

	        holdings.put(stock.getSymbol(),
	                holdings.getOrDefault(stock.getSymbol(), 0) + quantity);

	        cashBalance -= cost;
	        transactions.add(new Transaction("BUY", stock, quantity));
	        System.out.println("✅ Stock purchased successfully.");
	    }

	    public void sellStock(Stock stock, int quantity) {
	        int owned = holdings.getOrDefault(stock.getSymbol(), 0);

	        if (owned < quantity) {
	            System.out.println("❌ Not enough shares to sell.");
	            return;
	        }

	        holdings.put(stock.getSymbol(), owned - quantity);
	        cashBalance += stock.getPrice() * quantity;
	        transactions.add(new Transaction("SELL", stock, quantity));
	        System.out.println("✅ Stock sold successfully.");
	    }

	    public void displayPortfolio(Market market) {
	        System.out.println("\n📊 Portfolio Summary:");
	        double totalValue = cashBalance;

	        for (String symbol : holdings.keySet()) {
	            Stock stock = market.getStock(symbol);
	            int qty = holdings.get(symbol);
	            double value = qty * stock.getPrice();
	            totalValue += value;

	            System.out.println(symbol + ": " + qty +
	                    " shares (Value: $" + value + ")");
	        }

	        System.out.println("Cash Balance: $" + cashBalance);
	        System.out.println("Total Portfolio Value: $" + totalValue);
	    }

	    public void showTransactions() {
	        System.out.println("\n📜 Transaction History:");
	        for (Transaction t : transactions) {
	            System.out.println(t);
	        }
	    }
	}


