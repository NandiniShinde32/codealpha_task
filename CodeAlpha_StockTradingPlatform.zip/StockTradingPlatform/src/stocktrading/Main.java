package stocktrading;

public class Main {

	public static void main(String[] args) {
		        // Create Market and Portfolio objects
		        Market market = new Market();
		        Portfolio portfolio = new Portfolio();

		        // Add stocks to the market
		        market.addStock(new Stock("AAPL", "Apple", 150.0));
		        market.addStock(new Stock("GOOG", "Google", 2800.0));
		        market.addStock(new Stock("TSLA", "Tesla", 700.0));

		        // Display market data
		        market.displayMarket();

		        // Buy stocks
		        portfolio.buyStock(market.getStock("AAPL"), 10);
		        portfolio.buyStock(market.getStock("TSLA"), 5);

		        // Sell stock
		        portfolio.sellStock(market.getStock("AAPL"), 3);

		        // Display portfolio and transaction history
		        portfolio.displayPortfolio(market);
		        portfolio.showTransactions();
		    }
		}


	


