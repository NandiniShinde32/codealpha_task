package stocktrading;
import java.time.LocalDateTime;

public class Transaction {
	    private String type; // BUY or SELL
	    private Stock stock;
	    private int quantity;
	    private double totalPrice;
	    private LocalDateTime timestamp;

	    public Transaction(String type, Stock stock, int quantity) {
	        this.type = type;
	        this.stock = stock;
	        this.quantity = quantity;
	        this.totalPrice = stock.getPrice() * quantity;
	        this.timestamp = LocalDateTime.now();
	    }

	    @Override
	    public String toString() {
	        return type + " " + quantity + " shares of " +
	               stock.getSymbol() + " for $" + totalPrice +
	               " on " + timestamp;
	    }
	}


