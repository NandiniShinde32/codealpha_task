package studentgradetracker;  // keep this ONLY if Eclipse created it

import java.util.ArrayList;
import java.util.Scanner;

public class StudentGradeTracker {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        ArrayList<String> studentNames = new ArrayList<>();
        ArrayList<Integer> studentGrades = new ArrayList<>();

        System.out.print("Enter number of students: ");
        int numberOfStudents = scanner.nextInt();
        scanner.nextLine(); // consume newline

        for (int i = 0; i < numberOfStudents; i++) {
            System.out.print("Enter student name: ");
            String name = scanner.nextLine();
            studentNames.add(name);

            System.out.print("Enter grade for " + name + ": ");
            int grade = scanner.nextInt();
            scanner.nextLine(); // consume newline
            studentGrades.add(grade);
        }

        int total = 0;
        int highest = studentGrades.get(0);
        int lowest = studentGrades.get(0);

        for (int grade : studentGrades) {
            total += grade;
            if (grade > highest)
                highest = grade;
            if (grade < lowest)
                lowest = grade;
        }

        double average = (double) total / numberOfStudents;

        System.out.println("\n--- Student Grade Summary ---");
        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println(studentNames.get(i) + ": " + studentGrades.get(i));
        }

        System.out.println("\nAverage Score: " + average);
        System.out.println("Highest Score: " + highest);
        System.out.println("Lowest Score: " + lowest);

        scanner.close();
    }
}
